package awesome.navigation.compose

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import awesome.navigation.core.NavEntry
import awesome.navigation.core.NavRoute
import awesome.navigation.core.Navigator
import awesome.navigation.core.rememberNavigator


/**
 * 1. Public Inline Entry Point
 * Used by the app module to seamlessly initialize and manage the Navigator lifecycle.
 */
@Composable
inline fun <reified T : NavRoute> NavHost(
    initialRoute: T,
    modifier: Modifier = Modifier,
    noinline content: @Composable (T) -> Unit
) {
    val navigator = rememberNavigator(initialRoute)

    NavHost(
        navigator = navigator,
        modifier = modifier,
        content = content
    )
}

/**
 * 2. Core Layout Engine
 * Handles the Z-Stack rendering layout, systemic back presses, and CompositionLocal scoping.
 */
@Composable
fun <T : NavRoute> NavHost(
    navigator: Navigator<T>,
    modifier: Modifier = Modifier,
    content: @Composable (T) -> Unit
) {
    val entries by navigator.stack.collectAsState()

    // Handle system back button intercepting if stack can be popped
    val canPop = entries.size > 1
    BackHandler(enabled = canPop) {
        navigator.back()
    }

    @Suppress("UNCHECKED_CAST")
    CompositionLocalProvider(InternalLocalNavigator provides (navigator as Navigator<NavRoute>)) {
        Box(modifier = modifier.fillMaxSize()) {
            entries.forEach { entry ->
                key(entry.id) {
                    NavEntryWrapper(
                        entry = entry,
                        navigator = navigator,
                        content = { content(entry.route) }
                    )
                }
            }
        }
    }
}

/**
 * 3. Animation & Lifecycle Wrapper
 * Manages scoped ViewModelStores and executes entry/exit slide animations.
 */
@Composable
private fun <T : NavRoute> NavEntryWrapper(
    entry: NavEntry<T>,
    navigator: Navigator<T>,
    content: @Composable () -> Unit
) {
    val translationProgress = remember { Animatable(0f) }
    val isPopping = entry.isPopping

    // Animate item sliding inwards when pushed onto stack
    LaunchedEffect(entry.id) {
        val isRootScreen = navigator.stack.value.firstOrNull()?.id == entry.id
        if (!isRootScreen && !isPopping) {
            translationProgress.snapTo(1f)
            translationProgress.animateTo(0f, tween(300))
        }
    }

    // Animate item sliding outwards when popped off stack
    LaunchedEffect(isPopping) {
        if (isPopping) {
            translationProgress.animateTo(1f, tween(300))
            navigator.finalizeRemoval(entry.id)
        }
    }

    val owner = remember(entry.id) { NavViewModelStoreOwner(entry.vmStore) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                translationX = translationProgress.value * size.width
            }
    ) {
        CompositionLocalProvider(LocalViewModelStoreOwner provides owner) {
            content()
        }
    }
}

/**
 * 4. CompositionLocal Utilities
 * Exposes the active navigation controller across the entire UI tree.
 */
val InternalLocalNavigator = staticCompositionLocalOf<Navigator<NavRoute>> {
    error("No Navigator provided")
}

@Composable
@Suppress("UNCHECKED_CAST")
fun <T : NavRoute> ProvideNavigator(navigator: Navigator<T>, content: @Composable () -> Unit) {
    CompositionLocalProvider(InternalLocalNavigator provides (navigator as Navigator<NavRoute>)) {
        content()
    }
}

@Composable
@Suppress("UNCHECKED_CAST")
inline fun <reified T : NavRoute> currentNavigator(): Navigator<T> {
    return InternalLocalNavigator.current as Navigator<T>
}

/**
 * Bridges a NavEntry's dedicated ViewModelStore into the Jetpack Lifecycle ecosystem.
 */
private class NavViewModelStoreOwner(
    override val viewModelStore: ViewModelStore
) : ViewModelStoreOwner