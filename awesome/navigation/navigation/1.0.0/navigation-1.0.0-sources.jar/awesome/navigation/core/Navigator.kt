package awesome.navigation.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update



/**
 * The type-safe navigation engine. Strongly typed to the application's
 * localized root [NavRoute] interface via the generic parameter [T].
 */
class Navigator<T : NavRoute>(initialRoute: T) {

    private val _stack = MutableStateFlow<List<NavEntry<T>>>(
        listOf(NavEntry(route = initialRoute))
    )

    /**
     * The single source of truth for the active navigation stack hierarchy.
     */
    val stack: StateFlow<List<NavEntry<T>>> = _stack.asStateFlow()

    /**
     * Mutates the back stack according to the specified navigation mode configuration.
     */
    fun navigate(route: T, mode: NavMode<T> = NavMode.Push) {
        val newEntry = NavEntry(route = route)

        _stack.update { current ->
            when (mode) {
                is NavMode.Push -> {
                    current + newEntry
                }
                is NavMode.Replace -> {
                    // For immediate replacements, the dropped entry leaves composition immediately.
                    current.lastOrNull()?.vmStore?.clear()
                    current.dropLast(1) + newEntry
                }
                is NavMode.ClearAll -> {
                    current.forEach { it.vmStore.clear() }
                    listOf(newEntry)
                }
                is NavMode.PopUpTo -> {
                    val index = current.indexOfLast { mode.route.isInstance(it.route) }
                    if (index != -1) {
                        val targetIndex = if (mode.inclusive) index else index + 1

                        // Identify entries being dropped entirely and clear their VM allocations immediately
                        val fullyRemoved = current.subList(targetIndex, current.size)
                        fullyRemoved.forEach { it.vmStore.clear() }

                        current.take(targetIndex) + newEntry
                    } else {
                        // Fallback safely to a standard Push if the target route class isn't in history
                        current + newEntry
                    }
                }
            }
        }
    }

    /**
     * Phase 1 of Teardown: Marks the highest active screen as popping.
     * This triggers the horizontal sliding exit animation (~300ms) within the UI layer.
     * @return true if back press event was intercepted; false if down to the root screen layout.
     */
    fun back(): Boolean {
        var handled = false
        _stack.update { current ->
            val topNavigable = current.lastOrNull { !it.isPopping }
            val activeCount = current.count { !it.isPopping }

            if (topNavigable != null && activeCount > 1) {
                handled = true
                current.map { entry ->
                    if (entry.id == topNavigable.id) entry.copy(isPopping = true) else entry
                }
            } else {
                current // Allow native back handling to drop completely out of the app
            }
        }
        return handled
    }

    /**
     * Phase 2 of Teardown: Triggered automatically by the Composable wrapper once the transition finishes.
     * Drops the layout node out of the active list state flow and destroys its scoped ViewModel memory container.
     */
    fun finalizeRemoval(entryId: String) {
        _stack.update { current ->
            val entryToRemove = current.find { it.id == entryId }
            if (entryToRemove != null) {
                entryToRemove.vmStore.clear() // Free up allocated memory threads/coroutines
                current.filter { it.id != entryId }
            } else {
                current
            }
        }
    }
}