package awesome.navigation.core

import androidx.lifecycle.ViewModelStore
import kotlinx.serialization.Serializable

import java.util.UUID
import kotlin.reflect.KClass

/**
 * The type-safe foundation for all navigation destinations.
 * Every concrete route (data object or data class) must be annotated with @Serializable.
 */
interface NavRoute

data class NavEntry<T : NavRoute>(
    val id: String = UUID.randomUUID().toString(),
    val route: T,
    val isPopping: Boolean = false,
    val vmStore: ViewModelStore = ViewModelStore()
)

sealed class NavMode<out T : NavRoute> {
    data object Push : NavMode<Nothing>()
    data object Replace : NavMode<Nothing>()
    data object ClearAll : NavMode<Nothing>()
    data class PopUpTo<T : NavRoute>(
        val route: KClass<out T>,
        val inclusive: Boolean = false
    ) : NavMode<T>()
}
