package awesome.navigation.core

import java.lang.ref.WeakReference

object NavRegistry {
    private var activeNavigatorRef = WeakReference<Navigator<*>?>(null)

    /**
     * Internal library setter to bind the active engine.
     */
    internal fun register(navigator: Navigator<*>) {
        activeNavigatorRef = WeakReference(navigator)
    }

    /**
     * Internal library cleaner to prevent memory leaks.
     */
    internal fun unregister(navigator: Navigator<*>) {
        if (activeNavigatorRef.get() == navigator) {
            activeNavigatorRef.clear()
        }
    }

    /**
     * Safe global accessor for Activities, BroadcastReceivers, or ViewModels.
     */
    @Suppress("UNCHECKED_CAST")
    fun <T : NavRoute> get(): Navigator<T>? {
        return activeNavigatorRef.get() as? Navigator<T>
    }
}