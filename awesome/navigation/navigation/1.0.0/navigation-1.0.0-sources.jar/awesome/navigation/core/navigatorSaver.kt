package awesome.navigation.core

import androidx.compose.runtime.Composable
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.serialization.KSerializer
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import kotlinx.serialization.serializer

/**
 * A custom Compose Saver that handles process death recovery.
 * It serializes ONLY the structural List<NavRoute> to a JSON String.
 * On restoration, clean NavEntries (and fresh ViewModelStores) are recreated.
 */
/**
 * A custom Compose Saver that handles process death recovery for our generic Navigator.
 * Serializes ONLY the active structural List<T> routes to a JSON String.
 * On restoration, fresh NavEntries (and empty ViewModelStores) are cleanly recreated.
 */
fun <T : NavRoute> navigatorSaver(serializer: KSerializer<T>): Saver<Navigator<T>, String> = Saver(
    save = { navigator ->
        // Grab only the active routes that aren't actively being discarded by animations
        val activeRoutes = navigator.stack.value
            .filter { !it.isPopping }
            .map { it.route }

        // Explicitly serialize using a List wrapper of our specific route serializer
        Json.encodeToString(ListSerializer(serializer), activeRoutes)
    },
    restore = { jsonString ->
        val restoredRoutes = Json.decodeFromString(ListSerializer(serializer), jsonString)
        val initial = restoredRoutes.firstOrNull() ?: throw IllegalStateException("Stack cannot be empty")

        Navigator(initialRoute = initial).apply {
            // Reconstruct the structural back stack layout history
            restoredRoutes.drop(1).forEach { route ->
                this.navigate(route, NavMode.Push)
            }
        }
    }
)

/**
 * The clean, type-safe entry point for initializing your custom Navigator.
 * Uses inline + reified types to bypass JVM type erasure and fetch your serializer automatically.
 */
@Composable
inline fun <reified T : NavRoute> rememberNavigator(initialRoute: T): Navigator<T> {
    val targetSerializer = serializer<T>() // Generates the correct polymorphic serializer for your sealed tree
    return rememberSaveable(saver = navigatorSaver(targetSerializer)) {
        Navigator(initialRoute)
    }
}